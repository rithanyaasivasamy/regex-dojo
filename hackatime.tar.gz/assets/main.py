import asyncio
import math
import random
import sys

import pygame

WIDTH, HEIGHT = 1280, 720
RADIUS = 50


def check_circle_collision(circle_pos) -> bool:
    """Return True if the mouse is inside the circle."""
    mouse_pos = pygame.mouse.get_pos()
    distance = math.hypot(mouse_pos[0] - circle_pos[0], mouse_pos[1] - circle_pos[1])
    return distance <= RADIUS


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Click the Circle")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 30)

    score = 0
    circle_pos = (WIDTH // 2, HEIGHT // 2)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if check_circle_collision(circle_pos):
                    score += 1
                    # keep the whole circle on screen
                    circle_pos = (
                        random.randint(RADIUS, WIDTH - RADIUS),
                        random.randint(RADIUS, HEIGHT - RADIUS),
                    )

        screen.fill("lightblue")
        pygame.draw.circle(screen, "red", circle_pos, RADIUS)
        screen.blit(font.render(f"score: {score}", True, "black"), (50, 50))
        pygame.display.update()

        clock.tick(60)
        await asyncio.sleep(0)  # needed once per frame so pygbag can run it in a browser


asyncio.run(main())